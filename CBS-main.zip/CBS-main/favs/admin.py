from django.contrib import admin

from favs.models import Fav

admin.site.register(Fav)
